"use client"

import { MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function WhatsAppButton() {
  const handleWhatsAppClick = () => {
    const phoneNumber = "5511999999999" // Substitua pelo número real
    const message = "Olá! Gostaria de saber mais sobre as soluções da OLUMYA.IA"
    const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`
    window.open(url, "_blank")
  }

  return (
    <Button
      onClick={handleWhatsAppClick}
      className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-green-500 hover:bg-green-600 shadow-lg hover:shadow-xl transition-all duration-300 p-0"
      size="icon"
    >
      <MessageCircle className="w-6 h-6 text-white" />
      <span className="sr-only">Falar no WhatsApp</span>
    </Button>
  )
}

import { ArrowRight, Bot, Brain, MessageSquare, TrendingUp, Zap, Settings } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"

export default function ProdutosPage() {
  const products = [
    {
      icon: MessageSquare,
      title: "ChatBot IA Avançado",
      description: "Atendimento automatizado 24/7 com inteligência artificial conversacional",
      features: [
        "Processamento de linguagem natural",
        "Integração com CRM",
        "Análise de sentimentos",
        "Múltiplos canais de comunicação",
      ],
      image: "advanced AI chatbot interface with conversation flow",
      category: "Atendimento",
    },
    {
      icon: TrendingUp,
      title: "Análise Preditiva",
      description: "Preveja tendências e tome decisões estratégicas baseadas em dados",
      features: [
        "Machine Learning avançado",
        "Previsão de vendas",
        "Análise de comportamento",
        "Relatórios automatizados",
      ],
      image: "predictive analytics dashboard with charts and forecasting",
      category: "Analytics",
    },
    {
      icon: Zap,
      title: "Automação Inteligente",
      description: "Automatize processos complexos com workflows inteligentes",
      features: ["RPA com IA", "Workflows personalizáveis", "Integração com APIs", "Monitoramento em tempo real"],
      image: "intelligent automation workflow with connected processes",
      category: "Automação",
    },
    {
      icon: Brain,
      title: "Processamento de Documentos",
      description: "Extraia e processe informações de documentos automaticamente",
      features: ["OCR inteligente", "Classificação automática", "Extração de dados", "Validação inteligente"],
      image: "document processing AI with text extraction",
      category: "Documentos",
    },
    {
      icon: Bot,
      title: "Assistente Virtual",
      description: "Assistente IA personalizado para sua empresa",
      features: ["Comandos por voz", "Integração com sistemas", "Aprendizado contínuo", "Interface personalizada"],
      image: "virtual assistant interface with voice commands",
      category: "Assistente",
    },
    {
      icon: Settings,
      title: "Integração Personalizada",
      description: "Soluções sob medida para suas necessidades específicas",
      features: ["Desenvolvimento customizado", "APIs dedicadas", "Suporte especializado", "Escalabilidade garantida"],
      image: "custom integration dashboard with API connections",
      category: "Personalização",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <WhatsAppButton />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-purple-950/20 dark:via-blue-950/20 dark:to-indigo-950/20">
        <div className="absolute inset-0 bg-grid-black/[0.02] dark:bg-grid-white/[0.02]" />
        <div className="container mx-auto px-4 py-20 lg:py-32">
          <div className="text-center space-y-8 max-w-4xl mx-auto">
            <Badge variant="secondary" className="w-fit mx-auto">
              <Bot className="w-4 h-4 mr-2" />
              Nossos Produtos
            </Badge>
            <h1 className="text-4xl lg:text-6xl font-bold tracking-tight">
              Soluções de{" "}
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                IA Personalizadas
              </span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Descubra nossa linha completa de produtos de inteligência artificial desenvolvidos para transformar e
              otimizar seu negócio
            </p>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-20 lg:py-32">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product, index) => (
              <Card
                key={index}
                className="group hover:shadow-xl transition-all duration-300 overflow-hidden border-0 bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800"
              >
                <div className="aspect-video relative overflow-hidden">
                  <Image
                    src={`/placeholder.svg?height=300&width=400&query=${product.image}`}
                    alt={product.title}
                    width={400}
                    height={300}
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge variant="secondary">{product.category}</Badge>
                  </div>
                </div>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
                      <product.icon className="w-5 h-5 text-white" />
                    </div>
                    <CardTitle className="text-xl">{product.title}</CardTitle>
                  </div>
                  <CardDescription className="text-base">{product.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    {product.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-purple-500 to-blue-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full group-hover:bg-gradient-to-r group-hover:from-purple-600 group-hover:to-blue-600 transition-all">
                    Saiba Mais
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-8">
            <h2 className="text-3xl lg:text-5xl font-bold text-white">Precisa de uma solução personalizada?</h2>
            <p className="text-xl text-purple-100">
              Nossa equipe de especialistas pode desenvolver uma solução de IA sob medida para seu negócio
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary">
                Falar com Especialista
                <MessageSquare className="w-5 h-5 ml-2" />
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-purple-600 bg-transparent"
              >
                <Link href="/contato">Entre em Contato</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}

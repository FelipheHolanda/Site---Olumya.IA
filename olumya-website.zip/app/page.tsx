import { ArrowRight, Bot, Brain, CheckCircle, MessageSquare, Sparkles, Star, Users, Zap } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <WhatsAppButton />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-purple-950/20 dark:via-blue-950/20 dark:to-indigo-950/20">
        <div className="absolute inset-0 bg-grid-black/[0.02] dark:bg-grid-white/[0.02]" />
        <div className="container mx-auto px-4 py-20 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge variant="secondary" className="w-fit">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Inteligência Artificial Avançada
                </Badge>
                <h1 className="text-4xl lg:text-6xl font-bold tracking-tight">
                  Transforme seu negócio com{" "}
                  <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                    IA Inteligente
                  </span>
                </h1>
                <p className="text-xl text-muted-foreground max-w-2xl">
                  Soluções de inteligência artificial personalizadas para automatizar processos, aumentar produtividade
                  e impulsionar o crescimento do seu negócio.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  Começar Agora
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <Button size="lg" variant="outline">
                  Ver Demonstração
                </Button>
              </div>
              <div className="flex items-center gap-8 pt-4">
                <div className="flex items-center gap-2">
                  <div className="flex -space-x-2">
                    {[1, 2, 3, 4].map((i) => (
                      <div
                        key={i}
                        className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-400 to-blue-400 border-2 border-white"
                      />
                    ))}
                  </div>
                  <span className="text-sm text-muted-foreground">+500 empresas confiam</span>
                </div>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm text-muted-foreground ml-2">4.9/5</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-blue-400 rounded-3xl blur-3xl opacity-20" />
              <Image
                src="/placeholder.svg?height=600&width=600"
                alt="OLUMYA.IA Dashboard"
                width={600}
                height={600}
                className="relative rounded-3xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 lg:py-32">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-16">
            <Badge variant="secondary" className="w-fit mx-auto">
              <Bot className="w-4 h-4 mr-2" />
              Recursos Avançados
            </Badge>
            <h2 className="text-3xl lg:text-5xl font-bold">
              Por que escolher a{" "}
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                OLUMYA.IA
              </span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Nossa plataforma oferece soluções completas de IA para revolucionar a forma como você trabalha
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Brain,
                title: "IA Avançada",
                description: "Algoritmos de machine learning de última geração para resultados precisos",
              },
              {
                icon: Zap,
                title: "Automação Inteligente",
                description: "Automatize tarefas repetitivas e foque no que realmente importa",
              },
              {
                icon: MessageSquare,
                title: "Chatbots Inteligentes",
                description: "Atendimento 24/7 com respostas personalizadas e contextuais",
              },
              {
                icon: Users,
                title: "Análise de Dados",
                description: "Insights valiosos através de análise avançada de big data",
              },
              {
                icon: CheckCircle,
                title: "Integração Fácil",
                description: "Conecte facilmente com suas ferramentas e sistemas existentes",
              },
              {
                icon: Sparkles,
                title: "Personalização Total",
                description: "Soluções sob medida para as necessidades específicas do seu negócio",
              },
            ].map((feature, index) => (
              <Card
                key={index}
                className="group hover:shadow-lg transition-all duration-300 border-0 bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800"
              >
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Products Preview */}
      <section className="py-20 lg:py-32 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-16">
            <Badge variant="secondary" className="w-fit mx-auto">
              Nossos Produtos
            </Badge>
            <h2 className="text-3xl lg:text-5xl font-bold">
              Soluções completas de{" "}
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                Inteligência Artificial
              </span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "ChatBot IA",
                description: "Atendimento automatizado inteligente para seu site",
                image: "AI chatbot interface with conversation bubbles",
              },
              {
                title: "Análise Preditiva",
                description: "Preveja tendências e tome decisões baseadas em dados",
                image: "predictive analytics dashboard with graphs",
              },
              {
                title: "Automação de Processos",
                description: "Automatize workflows complexos com IA",
                image: "process automation workflow diagram",
              },
            ].map((product, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="aspect-video relative overflow-hidden">
                  <Image
                    src={`/placeholder.svg?height=300&width=400&query=${product.image}`}
                    alt={product.title}
                    width={400}
                    height={300}
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{product.title}</CardTitle>
                  <CardDescription className="text-base">{product.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    variant="outline"
                    className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors bg-transparent"
                  >
                    Saiba Mais
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button asChild size="lg">
              <Link href="/produtos">
                Ver Todos os Produtos
                <ArrowRight className="w-5 h-5 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-8">
            <h2 className="text-3xl lg:text-5xl font-bold text-white">Pronto para transformar seu negócio?</h2>
            <p className="text-xl text-purple-100">
              Junte-se a centenas de empresas que já estão usando nossas soluções de IA
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary">
                Falar com Consultor
                <MessageSquare className="w-5 h-5 ml-2" />
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-purple-600 bg-transparent"
              >
                <Link href="/planos">Ver Planos</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}

import { Check, Crown, MessageSquare, Star, Zap } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"

export default function PlanosPage() {
  const plans = [
    {
      name: "Starter",
      price: "R$ 297",
      period: "/mês",
      description: "Ideal para pequenas empresas que estão começando com IA",
      features: [
        "ChatBot básico",
        "Até 1.000 conversas/mês",
        "Integração com WhatsApp",
        "Suporte por email",
        "Dashboard básico",
        "1 usuário",
      ],
      popular: false,
      cta: "Começar Grátis",
    },
    {
      name: "Professional",
      price: "R$ 597",
      period: "/mês",
      description: "Para empresas em crescimento que precisam de mais recursos",
      features: [
        "ChatBot avançado",
        "Até 5.000 conversas/mês",
        "Múltiplos canais",
        "Análise preditiva básica",
        "Automação de processos",
        "Suporte prioritário",
        "Dashboard avançado",
        "Até 5 usuários",
        "Integrações personalizadas",
      ],
      popular: true,
      cta: "Teste Grátis por 14 dias",
    },
    {
      name: "Enterprise",
      price: "Personalizado",
      period: "",
      description: "Soluções completas para grandes empresas",
      features: [
        "Todas as funcionalidades",
        "Conversas ilimitadas",
        "IA personalizada",
        "Análise preditiva avançada",
        "Automação completa",
        "Suporte 24/7 dedicado",
        "Usuários ilimitados",
        "Integrações customizadas",
        "Treinamento da equipe",
        "SLA garantido",
      ],
      popular: false,
      cta: "Falar com Vendas",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <WhatsAppButton />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 dark:from-purple-950/20 dark:via-blue-950/20 dark:to-indigo-950/20">
        <div className="absolute inset-0 bg-grid-black/[0.02] dark:bg-grid-white/[0.02]" />
        <div className="container mx-auto px-4 py-20 lg:py-32">
          <div className="text-center space-y-8 max-w-4xl mx-auto">
            <Badge variant="secondary" className="w-fit mx-auto">
              <Crown className="w-4 h-4 mr-2" />
              Nossos Planos
            </Badge>
            <h1 className="text-4xl lg:text-6xl font-bold tracking-tight">
              Escolha o plano{" "}
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                ideal para você
              </span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Planos flexíveis que crescem com seu negócio. Comece grátis e escale conforme necessário.
            </p>
          </div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-20 lg:py-32">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan, index) => (
              <Card
                key={index}
                className={`relative overflow-hidden transition-all duration-300 ${
                  plan.popular ? "border-2 border-purple-500 shadow-2xl scale-105" : "hover:shadow-xl hover:scale-105"
                }`}
              >
                {plan.popular && (
                  <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-purple-600 to-blue-600 text-white text-center py-2 text-sm font-medium">
                    <Star className="w-4 h-4 inline mr-1" />
                    Mais Popular
                  </div>
                )}

                <CardHeader className={plan.popular ? "pt-12" : ""}>
                  <div className="text-center space-y-2">
                    <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    <div className="flex items-baseline justify-center gap-1">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-muted-foreground">{plan.period}</span>
                    </div>
                    <CardDescription className="text-base">{plan.description}</CardDescription>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-3">
                        <div className="w-5 h-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center flex-shrink-0">
                          <Check className="w-3 h-3 text-green-600 dark:text-green-400" />
                        </div>
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    className={`w-full ${
                      plan.popular
                        ? "bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                        : ""
                    }`}
                    variant={plan.popular ? "default" : "outline"}
                    size="lg"
                  >
                    {plan.cta}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Additional Info */}
          <div className="text-center mt-16 space-y-8">
            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold">Teste Grátis</h3>
                <p className="text-sm text-muted-foreground">14 dias grátis, sem compromisso</p>
              </div>
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center mx-auto">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold">Setup Rápido</h3>
                <p className="text-sm text-muted-foreground">Implementação em até 24 horas</p>
              </div>
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center mx-auto">
                  <MessageSquare className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold">Suporte Dedicado</h3>
                <p className="text-sm text-muted-foreground">Equipe especializada para ajudar</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold">
              Perguntas{" "}
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                Frequentes
              </span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                question: "Posso cancelar a qualquer momento?",
                answer: "Sim, você pode cancelar seu plano a qualquer momento sem taxas de cancelamento.",
              },
              {
                question: "Como funciona o período de teste?",
                answer: "Oferecemos 14 dias grátis para testar todas as funcionalidades do plano Professional.",
              },
              {
                question: "Há limite de integrações?",
                answer: "Não há limite de integrações nos planos Professional e Enterprise.",
              },
              {
                question: "O suporte está incluído?",
                answer: "Sim, todos os planos incluem suporte. O nível varia conforme o plano escolhido.",
              },
            ].map((faq, index) => (
              <Card key={index} className="border-0 bg-white dark:bg-gray-800">
                <CardHeader>
                  <CardTitle className="text-lg">{faq.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-8">
            <h2 className="text-3xl lg:text-5xl font-bold text-white">Ainda tem dúvidas?</h2>
            <p className="text-xl text-purple-100">
              Fale com nossos especialistas e descubra qual plano é ideal para seu negócio
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary">
                Falar com Consultor
                <MessageSquare className="w-5 h-5 ml-2" />
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-purple-600 bg-transparent"
              >
                <Link href="/contato">Agendar Demonstração</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
